To run:
   type - python q1.py
          python q2.py
